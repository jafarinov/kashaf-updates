/* محرك تحليل الإسناد — الكشّاف الجعفري للأسانيد.
   المدخل: رموز الرواية [[صيغة_قبل_الراوي, معرّف, لفظه في الإسناد], ...]
   المخرج: الحلقات والروابط والتنبيهات وموضع الضعف. */
(function (global) {
  'use strict';
  const DIAC = /[ً-ْٰـ]/g;
  const norm = s => (s || '').replace(DIAC, '').replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي')
    .replace(/[،,:؛.()«»"\-]/g, ' ').replace(/\s+/g, ' ').trim();

  /* مراتب الرواة: 1 أعلى ... 7 أدنى */
  const LEVELS = {
    1: { key: 'sahabi', label: 'صحبة' },
    2: { key: 'thiqa', label: 'ثقة' },
    3: { key: 'saduq', label: 'صدوق' },
    4: { key: 'layyin', label: 'صدوق يهم أو مقبول' },
    5: { key: 'daif', label: 'ضعيف أو مجهول' },
    6: { key: 'matruk', label: 'متروك' },
    7: { key: 'kadhdhab', label: 'متهم أو كذاب' },
  };
  function levelOf(text) {
    let t = norm(text);
    if (!t) return 0;
    // الضعف المقيد: «ثقة إلا في روايته عن فلان» — الحكم العام قبل القيد
    const restricted = /(الا في|في روايته عن|في حديثه عن|وضعيف في|ضعيف في حديث|حديثه عن \S+ ضعيف|تكلم في حديثه عن|تكلموا في روايته عن)/.exec(t);
    let base = restricted ? t.slice(0, restricted.index) : t;
    if (/مختلف في صحبت|لم تثبت (له )?صحب|لم يثبت له صحب/.test(base)) {
      const r = base.replace(/مختلف في صحبت\S*|لم تثبت (له )?صحب\S*|لم يثبت له صحب\S*|والراجح انه|والراجح انها|والاكثر انه/g, ' ');
      const lv = /والراجح انه تابعي|والراجح انها تابعية|تابعي/.test(r) ? (levelCore(r.replace(R1,' ')) || 3) : levelCore(r);
      return lv || 3;
    }
    return levelCore(base) || (restricted ? levelCore(t) : 0);
  }
  const W = (alts) => new RegExp('(^|\\s)(' + alts + ')(?=\\s|$)');
  const R7 = W('كذاب|وضاع|متهم|يكذب|متهم بالكذب|متهم بالوضع'), R7b = /يضع الحديث/;
  const R6 = W('متروك|واه|ساقط|متروك الحديث'), R6b = /منكر الحديث|ضعيف جدا|ضعيف الحديث جدا|ليس بشيء|ذاهب الحديث/;
  const R5 = W('ضعيف|مجهول|مجهولة|مستور|مستورة|ضعف'), R5b = /لا يعرف|ضعيف الحديث/;
  const R4 = W('مقبول|مقبولة|مفبول|لين'), R4b = /سي[ءئ] الحفظ|ساء حفظه|يخط[ئيى] كثيرا|كثير الخطا|كثير الغلط|كثير الاوهام|يهم كثيرا|انفرد ابن حبان|انفرد بتوثيقه|له مناكير|يتلقن|فيه لين|لين الحديث/;
  const R3 = W('صدوق|صدوقة'), R3b = /لا باس به|حسن الحديث|محله الصدق/;
  const R2 = W('ثقة|ثقه|ثبت|حافظ|امام|حجة|متقن|الحافظ|الامام|الحجة|الثقة'), R2b = /من الحفاظ|الاثبات|المتقنين/;
  const R1 = W('صحابي|صحابية|صحابيه'), R1b = /له صحبة|لها صحبة|له رؤية|لها رؤية/;
  function levelCore(t) {
    if (R1.test(t) || R1b.test(t)) return 1;
    // تُقدَّم الكلمة الأولى في الحكم: «صدوق سيء الحفظ» → فيه لين، «ثقة ... قيل: ضعيف» → ثقة
    if (R7.test(t) || R7b.test(t)) return 7;
    if (R6.test(t) || R6b.test(t)) return 6;
    const first = t.split(' ').slice(0, 4).join(' ');
    if (R5.test(first) || R5b.test(first)) return 5;
    if (R4.test(t) || R4b.test(t)) return 4;
    // صدوق يهم، صدوق يخطئ، له أوهام، تغير بأخرة... (المرتبة الخامسة عند ابن حجر)
    if (R3.test(first) && /يخط|يهم|اوهام|وهم|سي|ساء|تغير|اختلط|خلط|يغلط|خطا|يغرب|غرائب|مناكير|يدلس كثيرا/.test(t)) return 4;
    if (R3.test(first) || R3b.test(first)) return 3;
    if (R2.test(first) || R2b.test(first)) return 2;
    if (R3.test(t) || R3b.test(t)) return 3;
    if (R2.test(t) || R2b.test(t)) return 2;
    if (R5.test(t) || R5b.test(t)) return 5;
    if (/مخضرم|له ادراك|لها ادراك/.test(t)) return 2;
    return 0;
  }

  function opinion(n, who) {
    if (!n) return '';
    const o = (n.o || []).find(x => x[0].includes(who));
    return o ? o[1] : '';
  }
  function ibnHajar(n) { return (opinion(n, 'ابن حجر').split(/،\s*ومرة/)[0] || '').trim(); }
  function gradeText(n) { return ibnHajar(n) || n.r || ''; }
  function grade(n) {
    if (!n) return { level: 0, text: 'لا ترجمة له في الكشّاف', src: '' };
    const ih = ibnHajar(n);
    let lv = levelOf(ih);
    let src = 'ابن حجر';
    if (!lv) { lv = levelOf(n.r); src = 'خلاصة الرتبة'; }
    return { level: lv, text: ih || n.r || '—', src: ih ? 'ابن حجر' : src };
  }

  function snip(o, re) {
    const t = o[1]; const m = re.exec(t);
    if (!m || t.length <= 170) return [o[0], t];
    const a = Math.max(0, t.lastIndexOf('،', m.index - 40) + 1 || m.index - 70);
    return [o[0], (a > 0 ? '… ' : '') + t.slice(a, a + 170).trim() + (a + 170 < t.length ? ' …' : '')];
  }
  /* أوصاف مؤثرة في الاتصال */
  const allOps = n => (n && n.o || []).map(o => o[1]).join(' ¦ ');
  function tadlisInfo(n) {
    if (!n) return null;
    const hits = (n.o || []).filter(o => /دلس|التدليس/.test(norm(o[1])) && !/(لم|لا|ما) (يكن )?يدلس/.test(norm(o[1])));
    if (!hits.length && !/دلس/.test(norm(n.r))) return null;
    const mild = /يحتمل تدليسه|احتمل الائمة تدليسه|الثانية من المدلسين/.test(norm(allOps(n)));
    return { mild, quotes: hits.slice(0, 3).map(o => snip(o, /دلس/)) };
  }
  function ikhtilatInfo(n) {
    if (!n) return null;
    const hits = (n.o || []).filter(o => /اختلط|تغير|خلط بآخره|خلط باخره/.test(norm(o[1])));
    if (!hits.length && !/اختلط|تغير|خلط/.test(norm(n.r))) return null;
    return { quotes: hits.slice(0, 3).map(o => snip(o, /اختلط|تغير|خلط/)) };
  }
  const STOP = new Set(['بن', 'ابن', 'ابو', 'ابي', 'ابا', 'عبد', 'الله', 'محمد', 'بنت', 'ام', 'مولي', 'الرحمن', 'علي', 'احمد', 'عمر', 'بنت']);
  function nameKeys(n) {
    const src = norm((n.s || '') + ' ' + (n.k || ''));
    return [...new Set(src.split(' ').filter(w => w.length >= 3 && !STOP.has(w)))];
  }
  function irsalInfo(st, te) {
    if (!st || !te) return null;
    const keys = nameKeys(te);
    if (!keys.length) return null;
    for (const o of st.o || []) {
      const t = norm(o[1]);
      const m = /(لم يسمع من|لم يسمع|لم يلق|لم يدرك|ارسل عن|مرسل|لا يصح له سماع من|لم يثبت سماعه)/.exec(t);
      if (!m) continue;
      const win = t.slice(m.index, m.index + 70);
      if (keys.some(k => win.includes(k))) return { quote: o };
    }
    return null;
  }

  /* تصنيف الصيغة السابقة للراوي */
  const SAMA = /(حدثنا|حدثني|حدثتني|حدثناه|حدثنيه|اخبرنا|اخبرني|اخبرتني|انبانا|انباني|سمعت|سمع|سمعنا|ثنا|اخبرناه|قرات علي|قرئ علي)/;
  function classifySep(sep, i, surface) {
    const t = norm(sep);
    const sg = lastSighah(t);
    if (i === 0) return { kind: 'start', sighah: sg };
    const tail = t.split(' ').slice(-2).join(' ');
    const lastW = t.split(' ').pop() || '';
    // بداية إسناد جديد بعد متن أو تعليق: «... وحدثني»، «... حدثنا»
    const newChain = /^و?(حدثنا|حدثني|اخبرنا|اخبرني|انبانا|حدثناه|حدثنيه|اخبرناه|حدثناها)$/.test(lastW);
    if (/(^|\s)ح(\s|$)/.test(t)) return { kind: 'tahwil', sighah: sg };
    if (t.length > 45 && newChain) return { kind: 'next', sighah: sg };
    if (/^و(حدثنا|حدثني|اخبرنا|اخبرني|حدثناه|حدثنيه|انبانا|حدثناها)/.test(t)) return { kind: 'next', sighah: sg };
    if (t.length > 45 || /(قال ابو عيسي|قال ابو داود|قال ابو عبد الرحمن|وفي الباب|ورواه|رواه|تابعه|قال البخاري|قال مسلم|وقال)/.test(t))
      return { kind: 'aside', sighah: sg };
    if (t === '' || /^(و|ح و)$/.test(t) || /^و(عن|حدثنا|اخبرنا)?$/.test(t)) return { kind: 'atf', sighah: '' };
    return { kind: 'link', sighah: sg };
  }
  function lastSighah(t) {
    const words = t.split(' ');
    for (let k = words.length - 1; k >= 0; k--) {
      const w = words[k].replace(/^و/, '');
      if (SAMA.test(w)) return w;
      if (/^(عن|ان|قال|قالت|ذكر|زعم|يرفعه|بلغه|يبلغ|كلاهما عن|جميعا عن)$/.test(w)) return w;
      if (w === 'عن' || w === 'ان') return w;
    }
    return '';
  }
  const ambiguous = s => /^(عن|ان|قال|قالت|ذكر|زعم|)$/.test(s);

  function analyze(tokens, NAR) {
    const nodes = tokens.map(([sep, id, surface], i) => {
      const c = classifySep(sep, i, surface);
      const n = NAR[id];
      return { i, id, surface, sep, ...c, n, g: grade(n), student: null, group: null, flags: [] };
    });
    // ربط كل راوٍ بتلميذه في الإسناد
    let inAside = false;
    for (const x of nodes) {
      const prev = nodes[x.i - 1];
      if (x.kind === 'start' || x.kind === 'tahwil' || x.kind === 'next') { inAside = false; x.student = null; continue; }
      if (x.kind === 'aside') { inAside = true; }
      if (inAside) { x.aside = true; x.student = null; continue; }
      if (x.kind === 'atf') { x.student = prev ? prev.student : null; x.group = prev ? (prev.group ?? prev.i) : null; if (prev && prev.group == null) prev.group = prev.i; continue; }
      x.student = prev && !prev.aside ? prev.i : null;
    }
    const live = nodes.filter(x => !x.aside);
    // الطرق: كل راوٍ لا يروي عنه أحد بعده في الإسناد نهايةُ طريق، نصعد منه إلى شيخ المصنف
    const isStudent = new Set(live.filter(x => x.student != null).map(x => x.student));
    const chains = [];
    for (const x of live) {
      if (isStudent.has(x.i)) continue;
      if (x.group != null && live.some(y => y.group === x.group && y.i > x.i)) continue; // المعطوف عليه
      const ch = []; let cur = x;
      while (cur) { ch.unshift(cur); cur = cur.student != null ? nodes[cur.student] : null; }
      chains.push(ch);
    }
    const primary = chains[0] || [];
    const onPrimary = new Set(primary.map(x => x.i));
    // الفحوص على كل رابط (تلميذ ← شيخ)
    const links = [];
    for (const te of live) {
      if (te.student == null) continue;
      const st = nodes[te.student];
      const L = { st, te, sighah: te.sighah, flags: [] };
      const S = st.n, T = te.n;
      if (S && T) {
        const known = (S.T || []).includes(te.id) || (T.S || []).includes(st.id);
        if (!known) L.flags.push({ sev: 2, code: 'norel', title: 'رواية غير مذكورة', text: `لم يُذكر ${short(T)} في شيوخ ${short(S)}، ولا ${short(S)} في تلاميذه، في قائمة شيوخه وتلاميذه من تهذيب الكمال.` });
        if (S.tb && T.tb && T.tb > S.tb && T.tb !== 1)
          L.flags.push({ sev: 2, code: 'tabaka', title: 'طبقة الشيخ متأخرة', text: `طبقة ${short(T)} (${T.tb}) بعد طبقة تلميذه ${short(S)} (${S.tb}) في ترتيب التقريب.` });
        else if (S.tb && T.tb && S.tb - T.tb >= 4 && !known)
          L.flags.push({ sev: 2, code: 'gap', title: 'تباعد الطبقتين', text: `بين طبقة ${short(S)} (${S.tb}) وطبقة ${short(T)} (${T.tb}) فرق ${S.tb - T.tb} طبقات، مع عدم ذكر الرواية بينهما. يُحتمل سقوط راوٍ.` });
        const ir = irsalInfo(S, T);
        if (ir) L.flags.push({ sev: 3, code: 'irsal', title: 'نُصَّ على عدم السماع', text: `قال ${ir.quote[0]} في ${short(S)}: «${ir.quote[1]}»` });
      }
      const td = tadlisInfo(S);
      if (td && ambiguous(L.sighah)) {
        L.flags.push({ sev: td.mild ? 1 : 3, code: 'tadlis', title: td.mild ? 'عنعنة مدلس (يُحتمل تدليسه)' : 'عنعنة مدلس',
          text: `${short(S)} موصوف بالتدليس وروى هنا بصيغة «${L.sighah || 'محتملة'}».` + (td.quotes[0] ? ` قال ${td.quotes[0][0]}: «${td.quotes[0][1]}»` : '') });
      }
      const ik = ikhtilatInfo(T);
      if (ik) L.flags.push({ sev: 1, code: 'ikhtilat', title: 'شيخ اختلط أو تغيّر', text: `${short(T)} وُصف بالاختلاط أو التغير؛ يُنظر: هل سمع منه ${short(S)} قبل ذلك أم بعده؟` + (ik.quotes[0] ? ` قال ${ik.quotes[0][0]}: «${ik.quotes[0][1]}»` : '') });
      const restr = !T ? null : /(الا في|في روايته عن|في حديثه عن|ضعيف في حديث)/.exec(norm(gradeText(T)));
      if (restr && S) {
        const k = nameKeys(S);
        const tail = norm(gradeText(T)).slice(restr.index, restr.index + 60);
        if (k.some(w => tail.includes(w))) L.flags.push({ sev: 3, code: 'muqayyad', title: 'ضعف مقيّد بهذا الشيخ', text: `في ${short(T)}: «${gradeText(T)}»، والراوي عنه هنا ${short(S)}.` });
      }
      te.flags.push(...L.flags);
      links.push(L);
    }
    for (const x of live) if (!x.n) x.flags.push({ sev: 2, code: 'nomatch', title: 'لا ترجمة', text: 'الراوي غير مترجم في الكشّاف؛ يحتاج إلى تعيين يدوي.' });
    // موضع الضعف
    const worstLevel = Math.max(0, ...primary.map(x => x.g.level));
    const weakest = worstLevel >= 3 ? primary.filter(x => x.g.level === worstLevel) : [];
    const sevLinks = links.filter(l => onPrimary.has(l.te.i) && l.flags.some(f => f.sev >= 2));
    const chainInfo = chains.map(ch => { const w = Math.max(0, ...ch.map(x => x.g.level)); return { ch, worst: w }; });
    return { nodes, live, chains: chainInfo, primary, onPrimary, links, worstLevel, weakest, sevLinks,
      maxSev: Math.max(0, ...links.filter(l => onPrimary.has(l.te.i)).flatMap(l => l.flags.map(f => f.sev))) };
  }
  function short(n) { return n ? (n.s || n.a || '').trim() : 'راوٍ غير معيّن'; }

  /* شيوخ المصنف المباشرون في رواية: أول راوٍ في كل طريق، ومن عُطف عليه */
  function directShuyukh(a) {
    const out = [], seen = new Set();
    for (const x of a.live) {
      if (x.student != null) continue;
      if (!['start', 'tahwil', 'next', 'atf'].includes(x.kind)) continue;
      if (seen.has(x.id)) continue;
      seen.add(x.id);
      let sg = x.sighah;
      if (x.kind === 'atf') { const g = a.nodes.find(y => y.i === x.group); sg = g ? g.sighah : sg; }
      out.push({ id: x.id, sighah: sg, tahdith: SAMA.test(sg || '') });
    }
    return out;
  }
  global.IsnadEngine = { SAMA, directShuyukh, analyze, grade, levelOf, LEVELS, short, norm, ibnHajar, opinion };
})(window);
